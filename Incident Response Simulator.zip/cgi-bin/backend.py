#!/usr/bin/env python3
import cgi
import csv
import os

form = cgi.FieldStorage()

username = form.getvalue('username')
password = form.getvalue('password')
email = form.getvalue('email')

script_name = os.environ.get('SCRIPT_NAME', '')

if os.path.basename(script_name) == 'login.py':
    with open('users.csv', 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0] == username and row[2] == password:
                print("Content-Type: text/plain")
                print()
                print("Login successful!")
                break
        else:
            print("Content-Type: text/plain")
            print()
            print("Login failed!")

elif os.path.basename(script_name) == 'register.py':
    with open('users.csv', 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([username, email, password])
    print("Content-Type: text/plain")
    print()
    print("Registration successful!")

